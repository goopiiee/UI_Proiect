﻿namespace GUI
{
    partial class FereastraProduse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridProduse = new System.Windows.Forms.DataGridView();
            this.Inapoi = new System.Windows.Forms.Button();
            this.AfisareProduse = new System.Windows.Forms.Button();
            this.AdaugareProduse = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduse)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridProduse
            // 
            this.dataGridProduse.AllowUserToOrderColumns = true;
            this.dataGridProduse.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(251)))), ((int)(((byte)(231)))));
            this.dataGridProduse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridProduse.Location = new System.Drawing.Point(249, 27);
            this.dataGridProduse.Name = "dataGridProduse";
            this.dataGridProduse.RowHeadersWidth = 51;
            this.dataGridProduse.RowTemplate.Height = 24;
            this.dataGridProduse.Size = new System.Drawing.Size(555, 267);
            this.dataGridProduse.TabIndex = 7;
            // 
            // Inapoi
            // 
            this.Inapoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(227)))), ((int)(((byte)(208)))));
            this.Inapoi.FlatAppearance.BorderSize = 0;
            this.Inapoi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.Inapoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.Inapoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inapoi.Location = new System.Drawing.Point(66, 223);
            this.Inapoi.Name = "Inapoi";
            this.Inapoi.Size = new System.Drawing.Size(133, 33);
            this.Inapoi.TabIndex = 6;
            this.Inapoi.Text = "Inapoi";
            this.Inapoi.UseVisualStyleBackColor = false;
            this.Inapoi.Click += new System.EventHandler(this.Inapoi_Click);
            // 
            // AfisareProduse
            // 
            this.AfisareProduse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(232)))), ((int)(((byte)(208)))));
            this.AfisareProduse.FlatAppearance.BorderSize = 0;
            this.AfisareProduse.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.AfisareProduse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.AfisareProduse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AfisareProduse.Location = new System.Drawing.Point(12, 149);
            this.AfisareProduse.Name = "AfisareProduse";
            this.AfisareProduse.Size = new System.Drawing.Size(231, 71);
            this.AfisareProduse.TabIndex = 5;
            this.AfisareProduse.Text = "Afisare";
            this.AfisareProduse.UseVisualStyleBackColor = false;
            this.AfisareProduse.Click += new System.EventHandler(this.AfisareProduse_Click);
            // 
            // AdaugareProduse
            // 
            this.AdaugareProduse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(238)))), ((int)(((byte)(208)))));
            this.AdaugareProduse.FlatAppearance.BorderSize = 0;
            this.AdaugareProduse.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.AdaugareProduse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.AdaugareProduse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdaugareProduse.Location = new System.Drawing.Point(12, 73);
            this.AdaugareProduse.Name = "AdaugareProduse";
            this.AdaugareProduse.Size = new System.Drawing.Size(231, 73);
            this.AdaugareProduse.TabIndex = 4;
            this.AdaugareProduse.Text = "Adaugare";
            this.AdaugareProduse.UseVisualStyleBackColor = false;
            this.AdaugareProduse.Click += new System.EventHandler(this.AdaugareProduse_Click);
            // 
            // FereastraProduse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(246)))), ((int)(((byte)(208)))));
            this.ClientSize = new System.Drawing.Size(816, 316);
            this.Controls.Add(this.dataGridProduse);
            this.Controls.Add(this.Inapoi);
            this.Controls.Add(this.AfisareProduse);
            this.Controls.Add(this.AdaugareProduse);
            this.Name = "FereastraProduse";
            this.Text = "FereastraProduse";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduse)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridProduse;
        private System.Windows.Forms.Button Inapoi;
        private System.Windows.Forms.Button AfisareProduse;
        private System.Windows.Forms.Button AdaugareProduse;
    }
}