﻿namespace GUI
{
    partial class FereastraUseri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AdaugareUseri = new System.Windows.Forms.Button();
            this.AfisareUseri = new System.Windows.Forms.Button();
            this.Inapoi = new System.Windows.Forms.Button();
            this.dataGridUseri = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridUseri)).BeginInit();
            this.SuspendLayout();
            // 
            // AdaugareUseri
            // 
            this.AdaugareUseri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(185)))), ((int)(((byte)(168)))));
            this.AdaugareUseri.FlatAppearance.BorderSize = 0;
            this.AdaugareUseri.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(174)))), ((int)(((byte)(193)))));
            this.AdaugareUseri.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(174)))), ((int)(((byte)(193)))));
            this.AdaugareUseri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdaugareUseri.Location = new System.Drawing.Point(3, 96);
            this.AdaugareUseri.Name = "AdaugareUseri";
            this.AdaugareUseri.Size = new System.Drawing.Size(198, 84);
            this.AdaugareUseri.TabIndex = 0;
            this.AdaugareUseri.Text = "Adaugare";
            this.AdaugareUseri.UseVisualStyleBackColor = false;
            this.AdaugareUseri.Click += new System.EventHandler(this.AdaugareUseri_Click);
            // 
            // AfisareUseri
            // 
            this.AfisareUseri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(181)))), ((int)(((byte)(178)))));
            this.AfisareUseri.FlatAppearance.BorderSize = 0;
            this.AfisareUseri.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(174)))), ((int)(((byte)(193)))));
            this.AfisareUseri.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(174)))), ((int)(((byte)(193)))));
            this.AfisareUseri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AfisareUseri.Location = new System.Drawing.Point(3, 186);
            this.AfisareUseri.Name = "AfisareUseri";
            this.AfisareUseri.Size = new System.Drawing.Size(198, 71);
            this.AfisareUseri.TabIndex = 1;
            this.AfisareUseri.Text = "Afisare";
            this.AfisareUseri.UseVisualStyleBackColor = false;
            this.AfisareUseri.Click += new System.EventHandler(this.AfisareUseri_Click);
            // 
            // Inapoi
            // 
            this.Inapoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(176)))), ((int)(((byte)(188)))));
            this.Inapoi.FlatAppearance.BorderSize = 0;
            this.Inapoi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(174)))), ((int)(((byte)(193)))));
            this.Inapoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(174)))), ((int)(((byte)(193)))));
            this.Inapoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inapoi.Location = new System.Drawing.Point(66, 263);
            this.Inapoi.Name = "Inapoi";
            this.Inapoi.Size = new System.Drawing.Size(75, 30);
            this.Inapoi.TabIndex = 2;
            this.Inapoi.Text = "Inapoi";
            this.Inapoi.UseVisualStyleBackColor = false;
            this.Inapoi.Click += new System.EventHandler(this.Inapoi_Click);
            // 
            // dataGridUseri
            // 
            this.dataGridUseri.AllowUserToOrderColumns = true;
            this.dataGridUseri.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(223)))), ((int)(((byte)(207)))));
            this.dataGridUseri.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridUseri.Location = new System.Drawing.Point(207, 68);
            this.dataGridUseri.Name = "dataGridUseri";
            this.dataGridUseri.RowHeadersWidth = 51;
            this.dataGridUseri.RowTemplate.Height = 24;
            this.dataGridUseri.Size = new System.Drawing.Size(472, 239);
            this.dataGridUseri.TabIndex = 3;
            // 
            // FereastraUseri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(190)))), ((int)(((byte)(158)))));
            this.ClientSize = new System.Drawing.Size(704, 329);
            this.Controls.Add(this.dataGridUseri);
            this.Controls.Add(this.Inapoi);
            this.Controls.Add(this.AfisareUseri);
            this.Controls.Add(this.AdaugareUseri);
            this.Name = "FereastraUseri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FereastraUseri";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridUseri)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AdaugareUseri;
        private System.Windows.Forms.Button AfisareUseri;
        private System.Windows.Forms.Button Inapoi;
        private System.Windows.Forms.DataGridView dataGridUseri;
    }
}