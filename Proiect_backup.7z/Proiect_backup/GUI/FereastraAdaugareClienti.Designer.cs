﻿namespace GUI
{
    partial class FereastraAdaugareClienti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClientSalvare = new System.Windows.Forms.Button();
            this.textBoxPrenume = new System.Windows.Forms.TextBox();
            this.textBoxNume = new System.Windows.Forms.TextBox();
            this.UserPrenume = new System.Windows.Forms.Label();
            this.UserNume = new System.Windows.Forms.Label();
            this.textBoxAdresa = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ErrLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ClientSalvare
            // 
            this.ClientSalvare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(199)))), ((int)(((byte)(199)))));
            this.ClientSalvare.FlatAppearance.BorderSize = 0;
            this.ClientSalvare.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(182)))));
            this.ClientSalvare.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(182)))));
            this.ClientSalvare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClientSalvare.Location = new System.Drawing.Point(70, 56);
            this.ClientSalvare.Name = "ClientSalvare";
            this.ClientSalvare.Size = new System.Drawing.Size(264, 32);
            this.ClientSalvare.TabIndex = 9;
            this.ClientSalvare.Text = "Salvare";
            this.ClientSalvare.UseVisualStyleBackColor = false;
            this.ClientSalvare.Click += new System.EventHandler(this.ClientSalvare_Click);
            // 
            // textBoxPrenume
            // 
            this.textBoxPrenume.Location = new System.Drawing.Point(157, 28);
            this.textBoxPrenume.Name = "textBoxPrenume";
            this.textBoxPrenume.Size = new System.Drawing.Size(100, 22);
            this.textBoxPrenume.TabIndex = 8;
            // 
            // textBoxNume
            // 
            this.textBoxNume.Location = new System.Drawing.Point(21, 28);
            this.textBoxNume.Name = "textBoxNume";
            this.textBoxNume.Size = new System.Drawing.Size(100, 22);
            this.textBoxNume.TabIndex = 7;
            // 
            // UserPrenume
            // 
            this.UserPrenume.AutoSize = true;
            this.UserPrenume.Location = new System.Drawing.Point(165, 9);
            this.UserPrenume.Name = "UserPrenume";
            this.UserPrenume.Size = new System.Drawing.Size(61, 16);
            this.UserPrenume.TabIndex = 6;
            this.UserPrenume.Text = "Prenume";
            // 
            // UserNume
            // 
            this.UserNume.AutoSize = true;
            this.UserNume.Location = new System.Drawing.Point(46, 9);
            this.UserNume.Name = "UserNume";
            this.UserNume.Size = new System.Drawing.Size(43, 16);
            this.UserNume.TabIndex = 5;
            this.UserNume.Text = "Nume";
            // 
            // textBoxAdresa
            // 
            this.textBoxAdresa.Location = new System.Drawing.Point(282, 28);
            this.textBoxAdresa.Name = "textBoxAdresa";
            this.textBoxAdresa.Size = new System.Drawing.Size(100, 22);
            this.textBoxAdresa.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(304, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Adresa";
            // 
            // ErrLabel
            // 
            this.ErrLabel.AutoSize = true;
            this.ErrLabel.Location = new System.Drawing.Point(110, 91);
            this.ErrLabel.Name = "ErrLabel";
            this.ErrLabel.Size = new System.Drawing.Size(188, 16);
            this.ErrLabel.TabIndex = 15;
            this.ErrLabel.Text = "Datele trebuie sa fie complete!";
            // 
            // FereastraAdaugareClienti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(210)))), ((int)(((byte)(182)))));
            this.ClientSize = new System.Drawing.Size(397, 129);
            this.Controls.Add(this.ErrLabel);
            this.Controls.Add(this.textBoxAdresa);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ClientSalvare);
            this.Controls.Add(this.textBoxPrenume);
            this.Controls.Add(this.textBoxNume);
            this.Controls.Add(this.UserPrenume);
            this.Controls.Add(this.UserNume);
            this.Name = "FereastraAdaugareClienti";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FereastraAdaugareClienti";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ClientSalvare;
        private System.Windows.Forms.TextBox textBoxPrenume;
        private System.Windows.Forms.TextBox textBoxNume;
        private System.Windows.Forms.Label UserPrenume;
        private System.Windows.Forms.Label UserNume;
        private System.Windows.Forms.TextBox textBoxAdresa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ErrLabel;
    }
}