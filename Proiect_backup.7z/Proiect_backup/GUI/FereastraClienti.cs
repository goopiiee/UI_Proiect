﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;

namespace GUI
{
    public partial class FereastraClienti : Form
    {
        AdministrareClientiText adminClienti;
        public FereastraClienti()
        {
            string FisierClienti = ConfigurationManager.AppSettings["NumeFisierClienti"];
            string locatieFisierClientiSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierClienti = locatieFisierClientiSolutie + "\\" + FisierClienti;
            adminClienti = new AdministrareClientiText(caleCompletaFisierClienti);
            InitializeComponent();
            AfisareClientiGrid();
        }

        private void AdaugareClienti_Click(object sender, EventArgs e)
        {
            FereastraAdaugareClienti client = new FereastraAdaugareClienti();
            client.Show();
        }

        private void AfisareClienti_Click(object sender, EventArgs e)
        {
            AfisareClientiGrid();
        }

        private void Inapoi_Click(object sender, EventArgs e)
        {
            MeniuPrincipal principal = new MeniuPrincipal();
            principal.Show();
            this.Hide();
        }
        private void AfisareClientiGrid()
        {
            Clienti[] clienti = adminClienti.GetClienti(out int nrClienti);
            dataGridClienti.DataSource = clienti.Select(c => new { c.Nume, c.Prenume, c.Adresa }).ToList();
        }
    }
}
