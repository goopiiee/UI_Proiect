﻿namespace GUI
{
    partial class FereastraAdaugareComenzi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ComandaSalvare = new System.Windows.Forms.Button();
            this.textBoxMetPlata = new System.Windows.Forms.TextBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.UserPrenume = new System.Windows.Forms.Label();
            this.UserNume = new System.Windows.Forms.Label();
            this.ErrLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ComandaSalvare
            // 
            this.ComandaSalvare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.ComandaSalvare.FlatAppearance.BorderSize = 0;
            this.ComandaSalvare.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(245)))), ((int)(((byte)(213)))));
            this.ComandaSalvare.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(245)))), ((int)(((byte)(213)))));
            this.ComandaSalvare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComandaSalvare.Location = new System.Drawing.Point(50, 68);
            this.ComandaSalvare.Name = "ComandaSalvare";
            this.ComandaSalvare.Size = new System.Drawing.Size(185, 34);
            this.ComandaSalvare.TabIndex = 9;
            this.ComandaSalvare.Text = "Salvare";
            this.ComandaSalvare.UseVisualStyleBackColor = false;
            this.ComandaSalvare.Click += new System.EventHandler(this.ComandaSalvare_Click);
            // 
            // textBoxMetPlata
            // 
            this.textBoxMetPlata.Location = new System.Drawing.Point(129, 40);
            this.textBoxMetPlata.Name = "textBoxMetPlata";
            this.textBoxMetPlata.Size = new System.Drawing.Size(135, 22);
            this.textBoxMetPlata.TabIndex = 8;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(12, 40);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(100, 22);
            this.textBoxID.TabIndex = 7;
            // 
            // UserPrenume
            // 
            this.UserPrenume.AutoSize = true;
            this.UserPrenume.Location = new System.Drawing.Point(148, 9);
            this.UserPrenume.Name = "UserPrenume";
            this.UserPrenume.Size = new System.Drawing.Size(87, 16);
            this.UserPrenume.TabIndex = 6;
            this.UserPrenume.Text = "Metoda Plata";
            // 
            // UserNume
            // 
            this.UserNume.AutoSize = true;
            this.UserNume.Location = new System.Drawing.Point(51, 9);
            this.UserNume.Name = "UserNume";
            this.UserNume.Size = new System.Drawing.Size(20, 16);
            this.UserNume.TabIndex = 5;
            this.UserNume.Text = "ID";
            // 
            // ErrLabel
            // 
            this.ErrLabel.AutoSize = true;
            this.ErrLabel.Location = new System.Drawing.Point(47, 117);
            this.ErrLabel.Name = "ErrLabel";
            this.ErrLabel.Size = new System.Drawing.Size(188, 16);
            this.ErrLabel.TabIndex = 15;
            this.ErrLabel.Text = "Datele trebuie sa fie complete!";
            // 
            // FereastraAdaugareComenzi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(221)))), ((int)(((byte)(211)))));
            this.ClientSize = new System.Drawing.Size(288, 171);
            this.Controls.Add(this.ErrLabel);
            this.Controls.Add(this.ComandaSalvare);
            this.Controls.Add(this.textBoxMetPlata);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.UserPrenume);
            this.Controls.Add(this.UserNume);
            this.Name = "FereastraAdaugareComenzi";
            this.Text = "FereastraAdaugareComenzi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ComandaSalvare;
        private System.Windows.Forms.TextBox textBoxMetPlata;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.Label UserPrenume;
        private System.Windows.Forms.Label UserNume;
        private System.Windows.Forms.Label ErrLabel;
    }
}