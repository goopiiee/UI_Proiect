﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;

namespace GUI
{
    public partial class FereastraAdaugareComenzi : Form
    {
        AdministrareComenziText adminComenzi;
        public FereastraAdaugareComenzi()
        {
            string FisierComenzi = ConfigurationManager.AppSettings["NumeFisierComenzi"];
            string locatieFisierComenziSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierComenzi = locatieFisierComenziSolutie + "\\" + FisierComenzi;
            adminComenzi = new AdministrareComenziText(caleCompletaFisierComenzi);
            InitializeComponent();
            ErrLabel.Hide();
        }

        private void ComandaSalvare_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text == string.Empty || textBoxMetPlata.Text == String.Empty)
            {
                ErrLabel.Show();
            }
            else
            {
                ErrLabel.Hide();
                string id = textBoxID.Text;
                string metoda = textBoxMetPlata.Text;
                Comenzi comenzi = new Comenzi(Convert.ToInt32(id), metoda);
                adminComenzi.AddComenzi(comenzi);
                this.Hide();
            }
        }
    }
}
