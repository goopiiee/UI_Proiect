﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;


namespace GUI
{
    public partial class FereastraAdaugareProduse : Form
    {
        AdministrareProduseText adminProduse;
        public FereastraAdaugareProduse()
        {
            string FisierProduse = ConfigurationManager.AppSettings["NumeFisierProduse"];
            string locatieFisierProduseSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierProduse = locatieFisierProduseSolutie + "\\" + FisierProduse;
            adminProduse = new AdministrareProduseText(caleCompletaFisierProduse);
            InitializeComponent();
            ErrLabel.Hide();
        }

        private void ProdusSalvare_Click(object sender, EventArgs e)
        {
            if (textBoxDenumire.Text == String.Empty || textBoxCategorie.Text == String.Empty || textBoxPret.Text == string.Empty || textBoxCantitate.Text == String.Empty)
            {
                ErrLabel.Show();
            }
            else
            {   ErrLabel.Hide();
                string denumire = textBoxDenumire.Text;
                string categorie = textBoxCategorie.Text;
                string pret = textBoxPret.Text;
                string cantitate = textBoxCantitate.Text;
                Produse produsNou = new Produse(denumire, categorie, Convert.ToDecimal(pret), Convert.ToInt32(cantitate));
                adminProduse.AddProdus(produsNou);
                this.Hide();
            }
        }
    }
}
