﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;

namespace GUI
{
    public partial class FereastraProduse : Form
    {
        AdministrareProduseText adminProduse;
        public FereastraProduse()
        {
            string FisierProduse = ConfigurationManager.AppSettings["NumeFisierProduse"];
            string locatieFisierProduseSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierProduse = locatieFisierProduseSolutie + "\\" + FisierProduse;
            adminProduse = new AdministrareProduseText(caleCompletaFisierProduse);
            InitializeComponent();
            AfisareProduseGrid();
        }
        private void AdaugareProduse_Click(object sender, EventArgs e)
        {
            FereastraAdaugareProduse window = new FereastraAdaugareProduse();
            window.Show();
        }

        private void AfisareProduse_Click(object sender, EventArgs e)
        {
            AfisareProduseGrid();
        }
        private void AfisareProduseGrid()
        {
            Produse[] produse = adminProduse.GetProduse(out int nrProduse);
            dataGridProduse.DataSource = produse.Select(p => new { p.Denumire, p.Categorie, p.Pret, p.Cantitate }).ToList();
        }
        private void Inapoi_Click(object sender, EventArgs e)
        {
            MeniuPrincipal principal = new MeniuPrincipal();
            principal.Show();
            this.Hide();
        }      
    }
}
