﻿namespace GUI
{
    partial class FereastraClienti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridClienti = new System.Windows.Forms.DataGridView();
            this.Inapoi = new System.Windows.Forms.Button();
            this.AfisareClienti = new System.Windows.Forms.Button();
            this.AdaugareClienti = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridClienti)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridClienti
            // 
            this.dataGridClienti.AllowUserToOrderColumns = true;
            this.dataGridClienti.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(218)))));
            this.dataGridClienti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridClienti.Location = new System.Drawing.Point(236, 22);
            this.dataGridClienti.Name = "dataGridClienti";
            this.dataGridClienti.RowHeadersWidth = 51;
            this.dataGridClienti.RowTemplate.Height = 24;
            this.dataGridClienti.Size = new System.Drawing.Size(461, 253);
            this.dataGridClienti.TabIndex = 7;
            // 
            // Inapoi
            // 
            this.Inapoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(182)))), ((int)(((byte)(184)))));
            this.Inapoi.FlatAppearance.BorderSize = 0;
            this.Inapoi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(182)))), ((int)(((byte)(196)))));
            this.Inapoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(182)))), ((int)(((byte)(196)))));
            this.Inapoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inapoi.Location = new System.Drawing.Point(77, 226);
            this.Inapoi.Name = "Inapoi";
            this.Inapoi.Size = new System.Drawing.Size(88, 30);
            this.Inapoi.TabIndex = 6;
            this.Inapoi.Text = "Inapoi";
            this.Inapoi.UseVisualStyleBackColor = false;
            this.Inapoi.Click += new System.EventHandler(this.Inapoi_Click);
            // 
            // AfisareClienti
            // 
            this.AfisareClienti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(186)))), ((int)(((byte)(182)))));
            this.AfisareClienti.FlatAppearance.BorderSize = 0;
            this.AfisareClienti.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(182)))), ((int)(((byte)(196)))));
            this.AfisareClienti.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(182)))), ((int)(((byte)(196)))));
            this.AfisareClienti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AfisareClienti.Location = new System.Drawing.Point(15, 134);
            this.AfisareClienti.Name = "AfisareClienti";
            this.AfisareClienti.Size = new System.Drawing.Size(215, 86);
            this.AfisareClienti.TabIndex = 5;
            this.AfisareClienti.Text = "Afisare";
            this.AfisareClienti.UseVisualStyleBackColor = false;
            this.AfisareClienti.Click += new System.EventHandler(this.AfisareClienti_Click);
            // 
            // AdaugareClienti
            // 
            this.AdaugareClienti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(198)))), ((int)(((byte)(182)))));
            this.AdaugareClienti.FlatAppearance.BorderSize = 0;
            this.AdaugareClienti.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(182)))), ((int)(((byte)(196)))));
            this.AdaugareClienti.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(182)))), ((int)(((byte)(196)))));
            this.AdaugareClienti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdaugareClienti.Location = new System.Drawing.Point(15, 43);
            this.AdaugareClienti.Name = "AdaugareClienti";
            this.AdaugareClienti.Size = new System.Drawing.Size(215, 85);
            this.AdaugareClienti.TabIndex = 4;
            this.AdaugareClienti.Text = "Adaugare";
            this.AdaugareClienti.UseVisualStyleBackColor = false;
            this.AdaugareClienti.Click += new System.EventHandler(this.AdaugareClienti_Click);
            // 
            // FereastraClienti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(210)))), ((int)(((byte)(182)))));
            this.ClientSize = new System.Drawing.Size(709, 301);
            this.Controls.Add(this.dataGridClienti);
            this.Controls.Add(this.Inapoi);
            this.Controls.Add(this.AfisareClienti);
            this.Controls.Add(this.AdaugareClienti);
            this.Name = "FereastraClienti";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FereastraClienti";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridClienti)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridClienti;
        private System.Windows.Forms.Button Inapoi;
        private System.Windows.Forms.Button AfisareClienti;
        private System.Windows.Forms.Button AdaugareClienti;
    }
}