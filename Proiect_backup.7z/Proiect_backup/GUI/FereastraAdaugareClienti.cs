﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;


namespace GUI
{
    public partial class FereastraAdaugareClienti : Form
    {
        AdministrareClientiText adminClienti;
        public FereastraAdaugareClienti()
        {
            string FisierClienti = ConfigurationManager.AppSettings["NumeFisierClienti"];
            string locatieFisierClientiSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierClienti = locatieFisierClientiSolutie + "\\" + FisierClienti;
            adminClienti = new AdministrareClientiText(caleCompletaFisierClienti);
            InitializeComponent();
            ErrLabel.Hide();

        }

        private void ClientSalvare_Click(object sender, EventArgs e)
        {
            if (textBoxNume.Text == string.Empty || textBoxPrenume.Text == string.Empty || textBoxAdresa.Text == string.Empty)
            {
                ErrLabel.Show();
            }
            else
            {
                ErrLabel.Hide();
                string nume = textBoxNume.Text;
                string prenume = textBoxPrenume.Text;
                string adresa = textBoxAdresa.Text;
                Clienti clientNou = new Clienti(nume, prenume, adresa);
                adminClienti.AddClient(clientNou);
                this.Hide();
            }
        }
    }
}
