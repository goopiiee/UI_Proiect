﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;

namespace GUI
{
    public partial class LoginScreen : Form
    {
        public static string SetValueForUserValidation = "";
        AdministrareUseriText adminUseri;
        bool UUIDCorect = false;
        public LoginScreen()
        {
            string FisierUseri = ConfigurationManager.AppSettings["NumeFisierUseri"];
            string locatieFisierUseriSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierUseri = locatieFisierUseriSolutie + "\\" + FisierUseri;
            adminUseri = new AdministrareUseriText(caleCompletaFisierUseri);
            InitializeComponent();

            ErrLabel.Hide();
            Retry.Hide();

            LoginButton.Click += LoginButtonClicked;
            Retry.Click += LoginRetryButtonClicked;
        }
        private void LoginRetryButtonClicked(object sender, EventArgs e)
        {
            textBoxLogin.Text = String.Empty;
            LoginButton.Show();
            ErrLabel.Hide();
        }
        private void LoginButtonClicked(object sender, EventArgs e)
        {
            SetValueForUserValidation = textBoxLogin.Text;
            if (textBoxLogin.Text == String.Empty)
            {
                ErrLabel.Show();
                ErrLabel.Text = "Introduceti UUID";
            }
            else if(textBoxLogin.Text.Length!=4)
            {
                Retry.Show();
                LoginButton.Hide();
                ErrLabel.Show();
                ErrLabel.Text = "UUID trebuie sa aiba 4 cifre!";
            }
            else
            {
                string FisierUseri = ConfigurationManager.AppSettings["NumeFisierUseri"];
                string locatieFisierUseriSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
                string caleCompletaFisierUseri = locatieFisierUseriSolutie + "\\" + FisierUseri;
                adminUseri = new AdministrareUseriText(caleCompletaFisierUseri);
                Useri[] useri = adminUseri.GetUseri(out int nrUseri);
                foreach (Useri user in useri)
                {
                    if (textBoxLogin.Text == Convert.ToString(user.UserUniqueId))
                        UUIDCorect = true;
                }
                if (UUIDCorect == false)
                {
                    Retry.Show();
                    LoginButton.Hide();
                    ErrLabel.Show();
                    ErrLabel.Text = "UUID Necunoscut!";
                }
                else if (UUIDCorect == true)
                {
                    LoginButton.Hide();
                    textBoxLogin.Hide();
                    this.Hide();
                    MeniuPrincipal meniuPrincipal = new MeniuPrincipal();
                    meniuPrincipal.Show();
                }
            }
        }
        private void Retry_Click(object sender, EventArgs e)
        {
        }
    }
}
