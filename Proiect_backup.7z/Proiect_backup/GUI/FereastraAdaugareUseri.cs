﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;

namespace GUI
{
    public partial class FereastraAdaugareUseri : Form
    {
        AdministrareUseriText adminUseri;
        public FereastraAdaugareUseri()
        {
            string FisierUseri = ConfigurationManager.AppSettings["NumeFisierUseri"];
            string locatieFisierUseriSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierUseri = locatieFisierUseriSolutie + "\\" + FisierUseri;
            adminUseri = new AdministrareUseriText(caleCompletaFisierUseri);
            InitializeComponent();
            ErrTextBox.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBoxNume.Text == String.Empty || textBoxPrenume.Text == String.Empty)
            {
                ErrTextBox.Show();
            }
            else
            {
                ErrTextBox.Hide();
                string nume = textBoxNume.Text;
                string prenume = textBoxPrenume.Text;
                Useri userNou = new Useri(nume, prenume);
                adminUseri.AddUser(userNou);
                this.Hide();
            }
        }
    }
}
