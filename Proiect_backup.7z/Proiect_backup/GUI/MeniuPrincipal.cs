﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;

namespace GUI
{
    public partial class MeniuPrincipal : Form
    {
        public int AdminPassword;
        public MeniuPrincipal()
        {
            InitializeComponent();
            LoadingErr.Hide();
        }
        private void USERI_Click(object sender, EventArgs e)
        {
            AdminPassword = Convert.ToInt32(LoginScreen.SetValueForUserValidation);
            if (AdminPassword != 1234)
            {
                LoadingErr.Show();
            }
            else
            {
                LoadingErr.Hide();
                FereastraUseri window = new FereastraUseri();
                window.Show();
            }
        }

        private void CLIENTI_Click(object sender, EventArgs e)
        {
            FereastraClienti window = new FereastraClienti();
            window.Show();
        }

        private void COMENZI_Click(object sender, EventArgs e)
        {
            FereastraComenzi window = new FereastraComenzi();
            window.Show();
        }

        private void PRODUSE_Click(object sender, EventArgs e)
        {
            FereastraProduse window = new FereastraProduse();
            window.Show();
        }
    }
}
