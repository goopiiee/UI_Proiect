﻿namespace GUI
{
    partial class FereastraAdaugareProduse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProdusSalvare = new System.Windows.Forms.Button();
            this.textBoxCategorie = new System.Windows.Forms.TextBox();
            this.textBoxDenumire = new System.Windows.Forms.TextBox();
            this.ProdusCategorie = new System.Windows.Forms.Label();
            this.ProdusDenumire = new System.Windows.Forms.Label();
            this.textBoxCantitate = new System.Windows.Forms.TextBox();
            this.ProdusCantitate = new System.Windows.Forms.Label();
            this.textBoxPret = new System.Windows.Forms.TextBox();
            this.ProdusPret = new System.Windows.Forms.Label();
            this.ErrLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ProdusSalvare
            // 
            this.ProdusSalvare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(217)))), ((int)(((byte)(224)))));
            this.ProdusSalvare.FlatAppearance.BorderSize = 0;
            this.ProdusSalvare.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(206)))));
            this.ProdusSalvare.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(206)))));
            this.ProdusSalvare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ProdusSalvare.Location = new System.Drawing.Point(105, 72);
            this.ProdusSalvare.Name = "ProdusSalvare";
            this.ProdusSalvare.Size = new System.Drawing.Size(435, 33);
            this.ProdusSalvare.TabIndex = 9;
            this.ProdusSalvare.Text = "Salvare";
            this.ProdusSalvare.UseVisualStyleBackColor = false;
            this.ProdusSalvare.Click += new System.EventHandler(this.ProdusSalvare_Click);
            // 
            // textBoxCategorie
            // 
            this.textBoxCategorie.Location = new System.Drawing.Point(164, 44);
            this.textBoxCategorie.Name = "textBoxCategorie";
            this.textBoxCategorie.Size = new System.Drawing.Size(138, 22);
            this.textBoxCategorie.TabIndex = 8;
            // 
            // textBoxDenumire
            // 
            this.textBoxDenumire.Location = new System.Drawing.Point(12, 44);
            this.textBoxDenumire.Name = "textBoxDenumire";
            this.textBoxDenumire.Size = new System.Drawing.Size(131, 22);
            this.textBoxDenumire.TabIndex = 7;
            // 
            // ProdusCategorie
            // 
            this.ProdusCategorie.AutoSize = true;
            this.ProdusCategorie.Location = new System.Drawing.Point(193, 9);
            this.ProdusCategorie.Name = "ProdusCategorie";
            this.ProdusCategorie.Size = new System.Drawing.Size(66, 16);
            this.ProdusCategorie.TabIndex = 6;
            this.ProdusCategorie.Text = "Categorie";
            // 
            // ProdusDenumire
            // 
            this.ProdusDenumire.AutoSize = true;
            this.ProdusDenumire.Location = new System.Drawing.Point(33, 9);
            this.ProdusDenumire.Name = "ProdusDenumire";
            this.ProdusDenumire.Size = new System.Drawing.Size(65, 16);
            this.ProdusDenumire.TabIndex = 5;
            this.ProdusDenumire.Text = "Denumire";
            // 
            // textBoxCantitate
            // 
            this.textBoxCantitate.Location = new System.Drawing.Point(469, 44);
            this.textBoxCantitate.Name = "textBoxCantitate";
            this.textBoxCantitate.Size = new System.Drawing.Size(131, 22);
            this.textBoxCantitate.TabIndex = 11;
            // 
            // ProdusCantitate
            // 
            this.ProdusCantitate.AutoSize = true;
            this.ProdusCantitate.Location = new System.Drawing.Point(503, 9);
            this.ProdusCantitate.Name = "ProdusCantitate";
            this.ProdusCantitate.Size = new System.Drawing.Size(59, 16);
            this.ProdusCantitate.TabIndex = 10;
            this.ProdusCantitate.Text = "Cantitate";
            // 
            // textBoxPret
            // 
            this.textBoxPret.Location = new System.Drawing.Point(320, 44);
            this.textBoxPret.Name = "textBoxPret";
            this.textBoxPret.Size = new System.Drawing.Size(143, 22);
            this.textBoxPret.TabIndex = 13;
            // 
            // ProdusPret
            // 
            this.ProdusPret.AutoSize = true;
            this.ProdusPret.Location = new System.Drawing.Point(377, 9);
            this.ProdusPret.Name = "ProdusPret";
            this.ProdusPret.Size = new System.Drawing.Size(31, 16);
            this.ProdusPret.TabIndex = 12;
            this.ProdusPret.Text = "Pret";
            // 
            // ErrLabel
            // 
            this.ErrLabel.AutoSize = true;
            this.ErrLabel.Location = new System.Drawing.Point(238, 117);
            this.ErrLabel.Name = "ErrLabel";
            this.ErrLabel.Size = new System.Drawing.Size(188, 16);
            this.ErrLabel.TabIndex = 14;
            this.ErrLabel.Text = "Datele trebuie sa fie complete!";
            // 
            // FereastraAdaugareProduse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(238)))), ((int)(((byte)(208)))));
            this.ClientSize = new System.Drawing.Size(607, 160);
            this.Controls.Add(this.ErrLabel);
            this.Controls.Add(this.textBoxPret);
            this.Controls.Add(this.ProdusPret);
            this.Controls.Add(this.textBoxCantitate);
            this.Controls.Add(this.ProdusCantitate);
            this.Controls.Add(this.ProdusSalvare);
            this.Controls.Add(this.textBoxCategorie);
            this.Controls.Add(this.textBoxDenumire);
            this.Controls.Add(this.ProdusCategorie);
            this.Controls.Add(this.ProdusDenumire);
            this.Name = "FereastraAdaugareProduse";
            this.Text = "FereastraAdaugareProduse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ProdusSalvare;
        private System.Windows.Forms.TextBox textBoxCategorie;
        private System.Windows.Forms.TextBox textBoxDenumire;
        private System.Windows.Forms.Label ProdusCategorie;
        private System.Windows.Forms.Label ProdusDenumire;
        private System.Windows.Forms.TextBox textBoxCantitate;
        private System.Windows.Forms.Label ProdusCantitate;
        private System.Windows.Forms.TextBox textBoxPret;
        private System.Windows.Forms.Label ProdusPret;
        private System.Windows.Forms.Label ErrLabel;
    }
}