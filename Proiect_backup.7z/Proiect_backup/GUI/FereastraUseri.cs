﻿using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using proiect;
using Librarie_Modele;
using Nivel_Stocare_Date;

namespace GUI
{
    public partial class FereastraUseri : Form
    {
        AdministrareUseriText adminUseri;
        public FereastraUseri()
        {
            string FisierUseri = ConfigurationManager.AppSettings["NumeFisierUseri"];
            string locatieFisierUseriSolutie = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string caleCompletaFisierUseri = locatieFisierUseriSolutie + "\\" + FisierUseri;
            adminUseri = new AdministrareUseriText(caleCompletaFisierUseri);
            InitializeComponent();
            AfisareUseriGrid();
        }

        private void AdaugareUseri_Click(object sender, EventArgs e)
        {
            FereastraAdaugareUseri window = new FereastraAdaugareUseri();
            window.Show();
        }

        private void AfisareUseri_Click(object sender, EventArgs e)
        {
            AfisareUseriGrid();
        }

        private void Inapoi_Click(object sender, EventArgs e)
        {
            MeniuPrincipal principal = new MeniuPrincipal();
            principal.Show();
            this.Hide();
        }
        private void AfisareUseriGrid()
        {
            Useri[] useri = adminUseri.GetUseri(out int nrUseri);

            //!!!! Controlul de tip DataGridView are ca sursa de date lista de obiecte de tip Student 
            dataGridUseri.DataSource = useri.Select(u => new { u.Nume, u.Prenume, u.UserUniqueId }).ToList();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
