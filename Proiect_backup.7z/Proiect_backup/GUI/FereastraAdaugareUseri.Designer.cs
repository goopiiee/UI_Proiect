﻿namespace GUI
{
    partial class FereastraAdaugareUseri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserNume = new System.Windows.Forms.Label();
            this.UserPrenume = new System.Windows.Forms.Label();
            this.textBoxNume = new System.Windows.Forms.TextBox();
            this.textBoxPrenume = new System.Windows.Forms.TextBox();
            this.UserSalvare = new System.Windows.Forms.Button();
            this.ErrTextBox = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // UserNume
            // 
            this.UserNume.AutoSize = true;
            this.UserNume.Location = new System.Drawing.Point(41, 9);
            this.UserNume.Name = "UserNume";
            this.UserNume.Size = new System.Drawing.Size(43, 16);
            this.UserNume.TabIndex = 0;
            this.UserNume.Text = "Nume";
            // 
            // UserPrenume
            // 
            this.UserPrenume.AutoSize = true;
            this.UserPrenume.Location = new System.Drawing.Point(181, 9);
            this.UserPrenume.Name = "UserPrenume";
            this.UserPrenume.Size = new System.Drawing.Size(61, 16);
            this.UserPrenume.TabIndex = 1;
            this.UserPrenume.Text = "Prenume";
            // 
            // textBoxNume
            // 
            this.textBoxNume.Location = new System.Drawing.Point(22, 28);
            this.textBoxNume.Name = "textBoxNume";
            this.textBoxNume.Size = new System.Drawing.Size(100, 22);
            this.textBoxNume.TabIndex = 2;
            this.textBoxNume.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBoxPrenume
            // 
            this.textBoxPrenume.Location = new System.Drawing.Point(167, 28);
            this.textBoxPrenume.Name = "textBoxPrenume";
            this.textBoxPrenume.Size = new System.Drawing.Size(100, 22);
            this.textBoxPrenume.TabIndex = 3;
            this.textBoxPrenume.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // UserSalvare
            // 
            this.UserSalvare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(194)))), ((int)(((byte)(194)))));
            this.UserSalvare.FlatAppearance.BorderSize = 0;
            this.UserSalvare.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(217)))), ((int)(((byte)(167)))));
            this.UserSalvare.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(217)))), ((int)(((byte)(167)))));
            this.UserSalvare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UserSalvare.Location = new System.Drawing.Point(22, 56);
            this.UserSalvare.Name = "UserSalvare";
            this.UserSalvare.Size = new System.Drawing.Size(245, 45);
            this.UserSalvare.TabIndex = 4;
            this.UserSalvare.Text = "Salvare";
            this.UserSalvare.UseVisualStyleBackColor = false;
            this.UserSalvare.Click += new System.EventHandler(this.button1_Click);
            // 
            // ErrTextBox
            // 
            this.ErrTextBox.AutoSize = true;
            this.ErrTextBox.Location = new System.Drawing.Point(54, 104);
            this.ErrTextBox.Name = "ErrTextBox";
            this.ErrTextBox.Size = new System.Drawing.Size(188, 16);
            this.ErrTextBox.TabIndex = 5;
            this.ErrTextBox.Text = "Datele trebuie sa fie complete!";
            // 
            // FereastraAdaugareUseri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(185)))), ((int)(((byte)(168)))));
            this.ClientSize = new System.Drawing.Size(283, 140);
            this.Controls.Add(this.ErrTextBox);
            this.Controls.Add(this.UserSalvare);
            this.Controls.Add(this.textBoxPrenume);
            this.Controls.Add(this.textBoxNume);
            this.Controls.Add(this.UserPrenume);
            this.Controls.Add(this.UserNume);
            this.Name = "FereastraAdaugareUseri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FereastraAdaugareUseri";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UserNume;
        private System.Windows.Forms.Label UserPrenume;
        private System.Windows.Forms.TextBox textBoxNume;
        private System.Windows.Forms.TextBox textBoxPrenume;
        private System.Windows.Forms.Button UserSalvare;
        private System.Windows.Forms.Label ErrTextBox;
    }
}