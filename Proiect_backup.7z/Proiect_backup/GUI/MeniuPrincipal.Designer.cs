﻿namespace GUI
{
    partial class MeniuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.USERI = new System.Windows.Forms.Button();
            this.CLIENTI = new System.Windows.Forms.Button();
            this.COMENZI = new System.Windows.Forms.Button();
            this.PRODUSE = new System.Windows.Forms.Button();
            this.LoadingErr = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // USERI
            // 
            this.USERI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(190)))), ((int)(((byte)(158)))));
            this.USERI.FlatAppearance.BorderSize = 0;
            this.USERI.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.USERI.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.USERI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.USERI.Location = new System.Drawing.Point(40, 33);
            this.USERI.Name = "USERI";
            this.USERI.Size = new System.Drawing.Size(288, 89);
            this.USERI.TabIndex = 0;
            this.USERI.Text = "USERI";
            this.USERI.UseVisualStyleBackColor = false;
            this.USERI.Click += new System.EventHandler(this.USERI_Click);
            // 
            // CLIENTI
            // 
            this.CLIENTI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(210)))), ((int)(((byte)(182)))));
            this.CLIENTI.FlatAppearance.BorderSize = 0;
            this.CLIENTI.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.CLIENTI.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.CLIENTI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CLIENTI.Location = new System.Drawing.Point(40, 139);
            this.CLIENTI.Name = "CLIENTI";
            this.CLIENTI.Size = new System.Drawing.Size(288, 89);
            this.CLIENTI.TabIndex = 1;
            this.CLIENTI.Text = "CLIENTI";
            this.CLIENTI.UseVisualStyleBackColor = false;
            this.CLIENTI.Click += new System.EventHandler(this.CLIENTI_Click);
            // 
            // COMENZI
            // 
            this.COMENZI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(225)))), ((int)(((byte)(212)))));
            this.COMENZI.FlatAppearance.BorderSize = 0;
            this.COMENZI.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.COMENZI.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.COMENZI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.COMENZI.Location = new System.Drawing.Point(40, 248);
            this.COMENZI.Name = "COMENZI";
            this.COMENZI.Size = new System.Drawing.Size(288, 89);
            this.COMENZI.TabIndex = 2;
            this.COMENZI.Text = "COMENZI";
            this.COMENZI.UseVisualStyleBackColor = false;
            this.COMENZI.Click += new System.EventHandler(this.COMENZI_Click);
            // 
            // PRODUSE
            // 
            this.PRODUSE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(246)))), ((int)(((byte)(208)))));
            this.PRODUSE.FlatAppearance.BorderSize = 0;
            this.PRODUSE.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.PRODUSE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(192)))), ((int)(((byte)(190)))));
            this.PRODUSE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PRODUSE.Location = new System.Drawing.Point(40, 354);
            this.PRODUSE.Name = "PRODUSE";
            this.PRODUSE.Size = new System.Drawing.Size(288, 89);
            this.PRODUSE.TabIndex = 3;
            this.PRODUSE.Text = "PRODUSE";
            this.PRODUSE.UseVisualStyleBackColor = false;
            this.PRODUSE.Click += new System.EventHandler(this.PRODUSE_Click);
            // 
            // LoadingErr
            // 
            this.LoadingErr.AutoSize = true;
            this.LoadingErr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(190)))), ((int)(((byte)(158)))));
            this.LoadingErr.Location = new System.Drawing.Point(89, 90);
            this.LoadingErr.Name = "LoadingErr";
            this.LoadingErr.Size = new System.Drawing.Size(191, 16);
            this.LoadingErr.TabIndex = 4;
            this.LoadingErr.Text = "Doar Administratorul are acces";
            // 
            // MeniuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(105)))), ((int)(((byte)(122)))));
            this.ClientSize = new System.Drawing.Size(353, 465);
            this.Controls.Add(this.LoadingErr);
            this.Controls.Add(this.PRODUSE);
            this.Controls.Add(this.COMENZI);
            this.Controls.Add(this.CLIENTI);
            this.Controls.Add(this.USERI);
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Name = "MeniuPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MeniuPrincipal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button USERI;
        private System.Windows.Forms.Button CLIENTI;
        private System.Windows.Forms.Button COMENZI;
        private System.Windows.Forms.Button PRODUSE;
        private System.Windows.Forms.Label LoadingErr;
    }
}