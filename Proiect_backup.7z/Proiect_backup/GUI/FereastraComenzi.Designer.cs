﻿namespace GUI
{
    partial class FereastraComenzi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridComenzi = new System.Windows.Forms.DataGridView();
            this.Inapoi = new System.Windows.Forms.Button();
            this.AfisareComenzi = new System.Windows.Forms.Button();
            this.AdaugareComenzi = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridComenzi)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridComenzi
            // 
            this.dataGridComenzi.AllowUserToOrderColumns = true;
            this.dataGridComenzi.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(238)))), ((int)(((byte)(231)))));
            this.dataGridComenzi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridComenzi.Location = new System.Drawing.Point(239, 27);
            this.dataGridComenzi.Name = "dataGridComenzi";
            this.dataGridComenzi.RowHeadersWidth = 51;
            this.dataGridComenzi.RowTemplate.Height = 24;
            this.dataGridComenzi.Size = new System.Drawing.Size(377, 267);
            this.dataGridComenzi.TabIndex = 7;
            // 
            // Inapoi
            // 
            this.Inapoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(217)))), ((int)(((byte)(224)))));
            this.Inapoi.FlatAppearance.BorderSize = 0;
            this.Inapoi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(189)))), ((int)(((byte)(160)))));
            this.Inapoi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(189)))), ((int)(((byte)(160)))));
            this.Inapoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inapoi.Location = new System.Drawing.Point(71, 228);
            this.Inapoi.Name = "Inapoi";
            this.Inapoi.Size = new System.Drawing.Size(106, 31);
            this.Inapoi.TabIndex = 6;
            this.Inapoi.Text = "Inapoi";
            this.Inapoi.UseVisualStyleBackColor = false;
            this.Inapoi.Click += new System.EventHandler(this.Inapoi_Click);
            // 
            // AfisareComenzi
            // 
            this.AfisareComenzi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(223)))), ((int)(((byte)(224)))));
            this.AfisareComenzi.FlatAppearance.BorderSize = 0;
            this.AfisareComenzi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(189)))), ((int)(((byte)(160)))));
            this.AfisareComenzi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(189)))), ((int)(((byte)(160)))));
            this.AfisareComenzi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AfisareComenzi.Location = new System.Drawing.Point(12, 154);
            this.AfisareComenzi.Name = "AfisareComenzi";
            this.AfisareComenzi.Size = new System.Drawing.Size(221, 68);
            this.AfisareComenzi.TabIndex = 5;
            this.AfisareComenzi.Text = "Afisare";
            this.AfisareComenzi.UseVisualStyleBackColor = false;
            this.AfisareComenzi.Click += new System.EventHandler(this.AfisareComenzi_Click);
            // 
            // AdaugareComenzi
            // 
            this.AdaugareComenzi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(221)))), ((int)(((byte)(211)))));
            this.AdaugareComenzi.FlatAppearance.BorderSize = 0;
            this.AdaugareComenzi.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(189)))), ((int)(((byte)(160)))));
            this.AdaugareComenzi.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(189)))), ((int)(((byte)(160)))));
            this.AdaugareComenzi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdaugareComenzi.Location = new System.Drawing.Point(12, 73);
            this.AdaugareComenzi.Name = "AdaugareComenzi";
            this.AdaugareComenzi.Size = new System.Drawing.Size(221, 75);
            this.AdaugareComenzi.TabIndex = 4;
            this.AdaugareComenzi.Text = "Adaugare";
            this.AdaugareComenzi.UseVisualStyleBackColor = false;
            this.AdaugareComenzi.Click += new System.EventHandler(this.AdaugareComenzi_Click);
            // 
            // FereastraComenzi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(224)))), ((int)(((byte)(220)))));
            this.ClientSize = new System.Drawing.Size(628, 309);
            this.Controls.Add(this.dataGridComenzi);
            this.Controls.Add(this.Inapoi);
            this.Controls.Add(this.AfisareComenzi);
            this.Controls.Add(this.AdaugareComenzi);
            this.Name = "FereastraComenzi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FereastraComenzi";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridComenzi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridComenzi;
        private System.Windows.Forms.Button Inapoi;
        private System.Windows.Forms.Button AfisareComenzi;
        private System.Windows.Forms.Button AdaugareComenzi;
    }
}